SOURCEBOX RUNTIME CANDIDATE - NOT RELEASED

Contains the synchronization service, first-party adapters, modified SDK game
code and the original Shared Room geometry. Source SDK notices are in licenses/.
Distribution of the SDK-derived code must be free of charge.

No extracted Valve models, materials, maps or Workshop addon content is included.
The imported multiverse maps are disabled in this candidate configuration only.
Your existing configured runtime is unchanged.

This is not a complete installer. Local asset preparation, third-party loaders,
Node runtime acquisition and clean-PC acceptance are required before release.
Do not upload this candidate as a working public beta.

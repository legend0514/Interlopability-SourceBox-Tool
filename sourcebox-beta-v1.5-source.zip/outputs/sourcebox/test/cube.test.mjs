import {test} from 'node:test';import assert from 'node:assert/strict';import {createCube} from '../cube.mjs';
test('disabled Share Cube has no entities, grants or offline-owner notices',()=>{
 const sent=[],cube=createCube({definition:{enabled:false},clients:new Map(),emit:(...m)=>sent.push(m),log:()=>{}});
 const client={game:'tf2'};cube.welcome(client);cube.tick();cube.disconnect(client);
 for(const type of ['cube_take','cube_sync','cube_state','cube_frozen'])assert.equal(cube.handle(client,{type}),true);
 assert.deepEqual(sent,[]);assert.deepEqual(cube.inspect(),{enabled:false});assert.equal(cube.handle(client,{type:'portal_fire'}),false);
});
function rig(){let time=10000;const clients=new Map(['hl2','tf2'].map(game=>[game,{game,cubeProtocol:1,hasState:true,position:[0,128,0]}]));const sent=[];const cube=createCube({definition:{id:'cube',owner:'hl2',position:[0,128,32],cooldownMs:2000,freezeTimeoutMs:3000,claimDistance:160},clients,emit:(c,m)=>sent.push({game:c.game,...m}),log:()=>{},now:()=>time});return {cube,clients,sent,advance:ms=>time+=ms};}
test('cube requires old-owner deletion acknowledgement before grant; stale owner cannot overwrite',()=>{const r=rig(),h=r.clients.get('hl2'),t=r.clients.get('tf2');r.cube.handle(t,{type:'cube_take'});const request=r.sent.at(-1);assert.equal(request.type,'cube_freeze');assert.equal(r.cube.inspect().owner,'hl2');assert.equal(r.sent.some(m=>m.type==='cube_owner'),false);r.cube.handle(t,{type:'cube_frozen',epoch:1,transfer:request.transfer,state:r.cube.inspect().state});assert.equal(r.cube.inspect().owner,'hl2');r.cube.handle(h,{type:'cube_frozen',epoch:1,transfer:request.transfer,state:{...r.cube.inspect().state,timestamp:10}});assert.equal(r.cube.inspect().owner,'tf2');assert.equal(r.cube.inspect().epoch,2);r.cube.handle(h,{type:'cube_state',epoch:1,state:{...r.cube.inspect().state,position:[999,0,0],timestamp:11}});assert.deepEqual(r.cube.inspect().state.position,[0,128,32]);r.cube.handle(h,{type:'cube_take'});assert.equal(r.sent.at(-1).type,'cube_denied');r.advance(2001);r.cube.handle(h,{type:'cube_take'});const back=r.sent.at(-1);r.cube.handle(t,{type:'cube_frozen',epoch:2,transfer:back.transfer,state:{...r.cube.inspect().state,timestamp:12}});assert.equal(r.cube.inspect().owner,'hl2');assert.equal(r.cube.inspect().epoch,3);});
test('freeze timeout and disconnect cancel without granting a second owner',()=>{const r=rig(),t=r.clients.get('tf2');r.cube.handle(t,{type:'cube_take'});r.advance(3001);r.cube.tick();assert.equal(r.cube.inspect().owner,'hl2');assert.equal(r.cube.inspect().pending,null);r.cube.handle(t,{type:'cube_take'});r.clients.delete('tf2');r.cube.disconnect(t);assert.equal(r.cube.inspect().owner,'hl2');assert.equal(r.cube.inspect().pending,null);});
test('cube rejects distant requests, malformed snapshots and absent owner; reconnect retains authority',()=>{const r=rig(),t=r.clients.get('tf2'),h=r.clients.get('hl2');t.position=[900,0,0];r.cube.handle(t,{type:'cube_take'});assert.equal(r.sent.at(-1).type,'cube_denied');r.cube.handle(h,{type:'cube_state',epoch:1,state:{alive:true}});assert.equal(r.sent.at(-1).type,'cube_denied');r.clients.delete('hl2');t.position=[0,128,0];r.cube.handle(t,{type:'cube_take'});assert.equal(r.sent.at(-1).reason,'owner offline');r.cube.welcome(h);assert.equal(r.sent.at(-1).owner,'hl2');});
test('GMod takes and returns the cube only after each old owner freezes',()=>{
 const r=rig(),h=r.clients.get('hl2'),g={game:'gmod',cubeProtocol:1,hasState:true,position:[0,128,0]};r.clients.set('gmod',g);
 r.cube.handle(g,{type:'cube_take'});let request=r.sent.at(-1);assert.equal(request.game,'hl2');assert.equal(r.cube.inspect().owner,'hl2');
 r.cube.handle(h,{type:'cube_frozen',epoch:1,transfer:request.transfer,state:r.cube.inspect().state});assert.equal(r.cube.inspect().owner,'gmod');
 r.cube.handle(g,{type:'cube_state',epoch:2,state:{...r.cube.inspect().state,position:[10,128,32],timestamp:20}});assert.deepEqual(r.cube.inspect().state.position,[10,128,32]);
 r.advance(2001);r.cube.handle(h,{type:'cube_take'});request=r.sent.at(-1);assert.equal(request.game,'gmod');
 r.cube.handle(g,{type:'cube_frozen',epoch:2,transfer:request.transfer,state:r.cube.inspect().state});assert.equal(r.cube.inspect().owner,'hl2');
});

test('CS2 can take and return cube authority without accepting stale old-owner simulation',()=>{
 const r=rig(),h=r.clients.get('hl2'),c={game:'cs2',cubeProtocol:1,hasState:true,position:[0,128,0]};r.clients.set('cs2',c);
 r.cube.handle(c,{type:'cube_take'});let request=r.sent.at(-1);assert.equal(request.game,'hl2');assert.equal(r.cube.inspect().owner,'hl2');
 r.cube.handle(h,{type:'cube_frozen',epoch:1,transfer:request.transfer,state:r.cube.inspect().state});assert.equal(r.cube.inspect().owner,'cs2');
 r.cube.handle(c,{type:'cube_state',epoch:2,state:{...r.cube.inspect().state,position:[20,128,32],timestamp:40}});assert.deepEqual(r.cube.inspect().state.position,[20,128,32]);
 r.advance(2001);r.cube.handle(h,{type:'cube_take'});request=r.sent.at(-1);assert.equal(request.game,'cs2');
 r.cube.handle(c,{type:'cube_frozen',epoch:2,transfer:request.transfer,state:r.cube.inspect().state});assert.equal(r.cube.inspect().owner,'hl2');
 r.cube.handle(c,{type:'cube_state',epoch:2,state:{...r.cube.inspect().state,position:[999,999,999],timestamp:50}});assert.deepEqual(r.cube.inspect().state.position,[20,128,32]);
});
